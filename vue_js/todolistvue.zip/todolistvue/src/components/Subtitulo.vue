<script>
export default {
    data() {
        return {
            pText: "caracola",
        }
    }
}

</script>
<template>
    <p>{{ pText }}</p>
</template>
<style>
h1 {
    color: blue;
}
</style>